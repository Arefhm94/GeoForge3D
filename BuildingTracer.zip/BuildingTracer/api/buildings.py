"""
API endpoints for fetching building footprints.
"""
import os
import logging
from flask import Blueprint, request, jsonify
from marshmallow import ValidationError
from sqlalchemy import func

from api.schemas import BoundsSchema
from models import db, BuildingFootprint, BoundingBox
from utils.geo_utils import (
    fetch_osm_buildings,
    fetch_microsoft_buildings,
    merge_buildings
)

# Create a Blueprint for the buildings API
buildings_bp = Blueprint('buildings', __name__)
logger = logging.getLogger(__name__)

@buildings_bp.route('/buildings', methods=['POST'])
def get_buildings():
    """
    Fetch building footprints from OSM and Microsoft for a given area.
    
    Expects a JSON payload with bounds in the format:
    {
        "bounds": {
            "north": float,
            "south": float,
            "east": float,
            "west": float
        }
    }
    
    Returns:
        GeoJSON FeatureCollection of building footprints
    """
    try:
        # Get JSON data from request
        data = request.get_json()
        
        if not data or 'bounds' not in data:
            return jsonify({
                "error": "Missing required 'bounds' field in request"
            }), 400
        
        # Validate bounds using schema
        schema = BoundsSchema()
        try:
            bounds_data = schema.load(data['bounds'])
        except ValidationError as err:
            return jsonify({
                "error": "Invalid bounds parameters",
                "details": err.messages
            }), 400
        
        # Additional bounds validation (area size check for API performance)
        lat_diff = bounds_data['north'] - bounds_data['south']
        lon_diff = bounds_data['east'] - bounds_data['west']
        area = lat_diff * lon_diff
        
        if area > 1.0:
            return jsonify({
                "error": "Selected area too large",
                "details": "Please select a smaller area (maximum 1 square degree)"
            }), 400
        
        # Check if we have this data cached in the database
        try:
            # Create a record of this bounding box query
            bounding_box = BoundingBox.from_dict(bounds_data)
            db.session.add(bounding_box)
            db.session.commit()
            logger.debug(f"Created bounding box record with ID: {bounding_box.id}")
        except Exception as e:
            logger.warning(f"Could not create bounding box record: {str(e)}")
            db.session.rollback()
        
        # Fetch buildings from different sources
        osm_buildings = fetch_osm_buildings(bounds_data)
        ms_buildings = fetch_microsoft_buildings(bounds_data)
        
        # If both sources failed, return an error
        if not osm_buildings and not ms_buildings:
            return jsonify({
                "error": "Failed to fetch building data from any source"
            }), 500
        
        # Merge buildings from different sources
        result = merge_buildings(osm_buildings, ms_buildings)
        
        # Save buildings to database for caching
        try:
            # Update the bounding box with counts
            if bounding_box and bounding_box.id:
                bounding_box.osm_count = len(osm_buildings)
                bounding_box.microsoft_count = len(ms_buildings)
                db.session.commit()
                
            # Add new buildings to the database
            for feature in result.get('features', []):
                source = feature.get('properties', {}).get('source', 'unknown')
                
                # Check if building already exists
                source_id = feature.get('properties', {}).get('id')
                if source_id:
                    existing = BuildingFootprint.query.filter_by(
                        source=source, 
                        source_id=source_id
                    ).first()
                    
                    if existing:
                        # Skip if already exists
                        continue
                
                # Create new building record
                building = BuildingFootprint.from_geojson(feature, source)
                if building:
                    db.session.add(building)
            
            # Commit all buildings
            db.session.commit()
            logger.debug(f"Saved {len(result.get('features', []))} buildings to database")
            
        except Exception as e:
            logger.warning(f"Error saving buildings to database: {str(e)}")
            db.session.rollback()
        
        # Return GeoJSON response
        return jsonify(result)
        
    except Exception as e:
        logger.exception("Error processing building footprints request")
        return jsonify({
            "error": "An unexpected error occurred",
            "details": str(e)
        }), 500

@buildings_bp.route('/buildings/3d', methods=['POST'])
def get_buildings_3d():
    """
    Fetch building footprints with 3D data for a given area.
    
    Expects a JSON payload with bounds in the format:
    {
        "bounds": {
            "north": float,
            "south": float,
            "east": float,
            "west": float
        }
    }
    
    Returns:
        GeoJSON FeatureCollection of building footprints with height properties
    """
    try:
        # Get JSON data from request
        data = request.get_json()
        
        if not data or 'bounds' not in data:
            return jsonify({
                "error": "Missing required 'bounds' field in request"
            }), 400
        
        # Validate bounds using schema
        schema = BoundsSchema()
        try:
            bounds_data = schema.load(data['bounds'])
        except ValidationError as err:
            return jsonify({
                "error": "Invalid bounds parameters",
                "details": err.messages
            }), 400
        
        # Additional bounds validation (area size check for API performance)
        lat_diff = bounds_data['north'] - bounds_data['south']
        lon_diff = bounds_data['east'] - bounds_data['west']
        area = lat_diff * lon_diff
        
        if area > 0.05:  # More restrictive for 3D rendering
            return jsonify({
                "error": "Selected area too large",
                "details": "Please select a smaller area (maximum 0.05 square degree for 3D rendering)"
            }), 400
        
        # Query database for buildings in the specified area
        buildings = BuildingFootprint.query.filter(
            BuildingFootprint.properties.contains({
                'lat': {'$gte': bounds_data['south'], '$lte': bounds_data['north']},
                'lon': {'$gte': bounds_data['west'], '$lte': bounds_data['east']}
            })
        ).all()
        
        # If no buildings found in database, return an empty result
        if not buildings:
            return jsonify({
                "type": "FeatureCollection",
                "features": []
            })
        
        # Convert buildings to GeoJSON
        features = [building.to_geojson() for building in buildings]
        
        # Return GeoJSON response
        return jsonify({
            "type": "FeatureCollection",
            "features": features
        })
        
    except Exception as e:
        logger.exception("Error processing 3D building footprints request")
        return jsonify({
            "error": "An unexpected error occurred",
            "details": str(e)
        }), 500

@buildings_bp.route('/buildings/export/stl', methods=['POST'])
def export_buildings_stl():
    """
    Export buildings as STL file for 3D printing.
    
    Expects a JSON payload with bounds in the format:
    {
        "bounds": {
            "north": float,
            "south": float,
            "east": float,
            "west": float
        }
    }
    
    Returns:
        STL file as attachment
    """
    try:
        # Get JSON data from request
        data = request.get_json()
        
        if not data or 'bounds' not in data:
            return jsonify({
                "error": "Missing required 'bounds' field in request"
            }), 400
        
        # Validate bounds using schema
        schema = BoundsSchema()
        try:
            bounds_data = schema.load(data['bounds'])
        except ValidationError as err:
            return jsonify({
                "error": "Invalid bounds parameters",
                "details": err.messages
            }), 400
        
        # For now, just return a message - will implement actual STL export later
        return jsonify({
            "message": "STL export functionality will be implemented soon",
            "bounds": bounds_data
        })
        
    except Exception as e:
        logger.exception("Error processing STL export request")
        return jsonify({
            "error": "An unexpected error occurred",
            "details": str(e)
        }), 500

@buildings_bp.route('/buildings/stats', methods=['GET'])
def get_stats():
    """Get statistics about the building footprints database."""
    try:
        # Get counts by source
        osm_count = BuildingFootprint.query.filter_by(source='osm').count()
        ms_count = BuildingFootprint.query.filter_by(source='microsoft').count()
        
        # Get total count
        total_count = BuildingFootprint.query.count()
        
        # Get count of bounding boxes
        bbox_count = BoundingBox.query.count()
        
        # Get recent bounding boxes
        recent_queries = BoundingBox.query.order_by(
            BoundingBox.created_at.desc()
        ).limit(5).all()
        
        # Format response
        response = {
            "database_stats": {
                "total_buildings": total_count,
                "osm_buildings": osm_count,
                "microsoft_buildings": ms_count,
                "total_queries": bbox_count
            },
            "recent_queries": [box.to_dict() for box in recent_queries]
        }
        
        return jsonify(response)
        
    except Exception as e:
        logger.exception("Error getting database stats")
        return jsonify({
            "error": "An unexpected error occurred",
            "details": str(e)
        }), 500