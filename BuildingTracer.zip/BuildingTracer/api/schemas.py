"""
Schema definitions for request validation.
"""
from marshmallow import Schema, fields, validates_schema, ValidationError

class BoundsSchema(Schema):
    """Schema for validating boundary rectangle coordinates."""
    north = fields.Float(required=True, metadata={"description": "Northern latitude boundary"})
    south = fields.Float(required=True, metadata={"description": "Southern latitude boundary"})
    east = fields.Float(required=True, metadata={"description": "Eastern longitude boundary"})
    west = fields.Float(required=True, metadata={"description": "Western longitude boundary"})

    @validates_schema
    def validate_bounds(self, data, **kwargs):
        """Validate the bounds coordinates."""
        # Validate latitude (north/south)
        if data.get('north') is not None and (data['north'] < -90 or data['north'] > 90):
            raise ValidationError("North latitude must be between -90 and 90 degrees", "north")
            
        if data.get('south') is not None and (data['south'] < -90 or data['south'] > 90):
            raise ValidationError("South latitude must be between -90 and 90 degrees", "south")
        
        # Validate longitude (east/west)
        if data.get('east') is not None and (data['east'] < -180 or data['east'] > 180):
            raise ValidationError("East longitude must be between -180 and 180 degrees", "east")
            
        if data.get('west') is not None and (data['west'] < -180 or data['west'] > 180):
            raise ValidationError("West longitude must be between -180 and 180 degrees", "west")
        
        # Validate north is greater than south
        if (data.get('north') is not None and data.get('south') is not None 
                and data['north'] <= data['south']):
            raise ValidationError("North latitude must be greater than south latitude", "north")