"""
API package initialization.
"""