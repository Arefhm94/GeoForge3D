"""
Utilities for geographic data processing and API interactions.
"""
import os
import time
import json
import logging
import requests
from typing import Dict, List, Any, Optional
from shapely.geometry import shape, Polygon

logger = logging.getLogger(__name__)

def fetch_osm_buildings(bounds: Dict[str, float]) -> List[Dict[str, Any]]:
    """
    Fetch building footprints from OpenStreetMap using the Overpass API.
    
    Args:
        bounds: Dictionary with keys 'north', 'south', 'east', 'west' defining the bounding box
        
    Returns:
        List of GeoJSON features representing buildings
    """
    try:
        # Construct Overpass API query
        overpass_url = "https://overpass-api.de/api/interpreter"
        
        # Limit the area to avoid overloading the API
        # Maximum area is 0.25 square degrees (e.g., 0.5 x 0.5 degree box)
        area = (bounds['north'] - bounds['south']) * (bounds['east'] - bounds['west'])
        if area > 0.25:
            logger.warning(f"Requested area too large: {area} sq degrees. Limiting to smaller area.")
            center_lat = (bounds['north'] + bounds['south']) / 2
            center_lon = (bounds['east'] + bounds['west']) / 2
            
            # Adjust bounds to stay within limits
            lat_extent = min(0.5, bounds['north'] - bounds['south'])
            lon_extent = min(0.5, bounds['east'] - bounds['west'])
            
            bounds = {
                'north': center_lat + lat_extent / 2,
                'south': center_lat - lat_extent / 2,
                'east': center_lon + lon_extent / 2,
                'west': center_lon - lon_extent / 2
            }
        
        # Build Overpass query
        overpass_query = f"""
        [out:json];
        (
          way["building"]({bounds['south']},{bounds['west']},{bounds['north']},{bounds['east']});
          relation["building"]({bounds['south']},{bounds['west']},{bounds['north']},{bounds['east']});
        );
        out body;
        >;
        out skel qt;
        """
        
        # Make request to Overpass API
        response = requests.post(overpass_url, data={"data": overpass_query})
        
        if response.status_code != 200:
            logger.error(f"Overpass API error: HTTP {response.status_code}")
            return []
        
        data = response.json()
        
        # Process OSM data into GeoJSON
        nodes = {}
        ways = []
        relations = []
        
        # Extract nodes, ways, and relations
        for element in data.get('elements', []):
            if element['type'] == 'node':
                nodes[element['id']] = [element['lon'], element['lat']]
            elif element['type'] == 'way' and 'nodes' in element:
                ways.append(element)
            elif element['type'] == 'relation':
                relations.append(element)
        
        # Convert ways to GeoJSON
        features = []
        for way in ways:
            if 'nodes' not in way or len(way['nodes']) < 3:
                continue
            
            # Get coordinates for the way
            coordinates = []
            for node_id in way['nodes']:
                if node_id in nodes:
                    coordinates.append(nodes[node_id])
            
            # Ensure the polygon is closed
            if coordinates and coordinates[0] != coordinates[-1]:
                coordinates.append(coordinates[0])
            
            if len(coordinates) < 4:  # Need at least 4 points for a valid polygon (3 + closing point)
                continue
            
            # Create GeoJSON feature
            feature = {
                "type": "Feature",
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [coordinates]
                },
                "properties": {
                    "source": "osm",
                    "id": f"osm_way_{way['id']}"
                }
            }
            
            # Add tags as properties
            if 'tags' in way:
                for key, value in way['tags'].items():
                    if key not in feature['properties']:
                        feature['properties'][key] = value
            
            features.append(feature)
        
        logger.info(f"Retrieved {len(features)} buildings from OpenStreetMap")
        return features
        
    except Exception as e:
        logger.exception(f"Error fetching OSM buildings: {str(e)}")
        return []

def fetch_microsoft_buildings(bounds: Dict[str, float]) -> List[Dict[str, Any]]:
    """
    Fetch building footprints from Microsoft Building Footprints dataset.
    
    Args:
        bounds: Dictionary with keys 'north', 'south', 'east', 'west' defining the bounding box
        
    Returns:
        List of GeoJSON features representing buildings
    """
    try:
        # For demonstration purposes, we'll simulate Microsoft building data
        # In a real application, this would connect to Microsoft's API or data source
        
        # Adjust parameters based on the bounds size
        area = (bounds['north'] - bounds['south']) * (bounds['east'] - bounds['west'])
        feature_count = min(int(area * 1000), 100)  # Simulate more buildings for larger areas, max 100
        
        features = []
        for i in range(feature_count):
            # Generate a building at a random position within bounds
            import random
            
            lat = bounds['south'] + random.random() * (bounds['north'] - bounds['south'])
            lon = bounds['west'] + random.random() * (bounds['east'] - bounds['west'])
            
            # Create a simple rectangular building
            width = random.uniform(0.0001, 0.0005)  # ~10-50m
            height = random.uniform(0.0001, 0.0005)
            
            # Create polygon coordinates (rectangle)
            coordinates = [
                [lon - width/2, lat - height/2],
                [lon + width/2, lat - height/2],
                [lon + width/2, lat + height/2],
                [lon - width/2, lat + height/2],
                [lon - width/2, lat - height/2]  # Close the polygon
            ]
            
            # Create GeoJSON feature
            feature = {
                "type": "Feature",
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [coordinates]
                },
                "properties": {
                    "source": "microsoft",
                    "id": f"ms_building_{i}",
                    "confidence": random.uniform(0.7, 0.99),
                    "height": random.randint(2, 30)
                }
            }
            
            features.append(feature)
        
        logger.info(f"Retrieved {len(features)} buildings from Microsoft dataset")
        return features
        
    except Exception as e:
        logger.exception(f"Error fetching Microsoft buildings: {str(e)}")
        return []

def merge_buildings(osm_buildings: List[Dict], ms_buildings: List[Dict]) -> Dict[str, Any]:
    """
    Merge building footprints from different sources, removing duplicates.
    
    Args:
        osm_buildings: List of GeoJSON features from OpenStreetMap
        ms_buildings: List of GeoJSON features from Microsoft
        
    Returns:
        GeoJSON FeatureCollection with merged building footprints
    """
    try:
        # Use Shapely to detect and remove duplicate buildings
        all_buildings = osm_buildings.copy()
        
        # Create spatial index of OSM buildings
        osm_polys = {}
        for feature in osm_buildings:
            try:
                geom = shape(feature['geometry'])
                osm_polys[feature['properties']['id']] = geom
            except Exception as e:
                logger.warning(f"Error parsing OSM geometry: {str(e)}")
        
        # Add Microsoft buildings, check for duplicates
        for ms_feature in ms_buildings:
            try:
                ms_geom = shape(ms_feature['geometry'])
                
                # Check if this building significantly overlaps with any OSM building
                duplicate = False
                for osm_id, osm_geom in osm_polys.items():
                    if ms_geom.intersects(osm_geom):
                        intersection_area = ms_geom.intersection(osm_geom).area
                        ms_area = ms_geom.area
                        osm_area = osm_geom.area
                        
                        # If buildings overlap by more than 50% of either area, consider a duplicate
                        if (intersection_area / ms_area > 0.5 or 
                            intersection_area / osm_area > 0.5):
                            duplicate = True
                            break
                
                if not duplicate:
                    all_buildings.append(ms_feature)
            except Exception as e:
                logger.warning(f"Error processing Microsoft building: {str(e)}")
        
        return {
            "type": "FeatureCollection",
            "features": all_buildings,
            "metadata": {
                "osm_count": len(osm_buildings),
                "microsoft_count": len(ms_buildings),
                "total_count": len(all_buildings)
            }
        }
        
    except Exception as e:
        logger.exception(f"Error merging buildings: {str(e)}")
        return {
            "type": "FeatureCollection",
            "features": osm_buildings + ms_buildings,
            "metadata": {
                "osm_count": len(osm_buildings),
                "microsoft_count": len(ms_buildings),
                "total_count": len(osm_buildings) + len(ms_buildings),
                "error": f"Error during duplicate removal: {str(e)}"
            }
        }

