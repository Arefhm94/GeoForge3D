"""
Main entry point for the Building Footprints Mapper application.
"""
import os
import logging
from flask import Flask, render_template
from models import db

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "development-secret-key")

# Configure database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize database
db.init_app(app)

# Import and register blueprints
from api.buildings import buildings_bp

# Register blueprints
app.register_blueprint(buildings_bp, url_prefix='/api')

# Create database tables
with app.app_context():
    db.create_all()

# Routes
@app.route('/')
def index():
    """Render the main page with the map interface."""
    return render_template('index.html')
    
@app.route('/stats')
def stats():
    """Render the statistics page."""
    return render_template('stats.html')
    
@app.route('/3d')
def view_3d():
    """Render the 3D visualization page."""
    return render_template('3d.html')

# Error handlers
@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors."""
    return render_template('error.html', error_code=404, error_message="Page not found"), 404

@app.errorhandler(500)
def server_error(error):
    """Handle 500 errors."""
    logger.exception("Server error")
    return render_template('error.html', error_code=500, error_message="Server error"), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)