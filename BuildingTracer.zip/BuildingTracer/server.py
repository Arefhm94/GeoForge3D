"""
Server module for the Building Footprints Mapper application.
This module is deprecated and has been replaced by main.py.
Kept for backward compatibility.
"""
from main import app

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)