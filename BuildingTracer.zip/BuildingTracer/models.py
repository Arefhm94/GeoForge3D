"""
Database models for Building Footprints Mapper.
"""
import json
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.dialects.postgresql import JSONB

# Initialize SQLAlchemy
db = SQLAlchemy()

class BuildingFootprint(db.Model):
    """Model to store building footprint data."""
    
    __tablename__ = 'building_footprints'
    
    id = db.Column(db.Integer, primary_key=True)
    source = db.Column(db.String(50), nullable=False)  # 'osm' or 'microsoft'
    source_id = db.Column(db.String(255), nullable=True)  # ID from the source system
    geometry = db.Column(JSONB, nullable=False)  # GeoJSON geometry
    properties = db.Column(JSONB, nullable=True)  # Additional properties
    area = db.Column(db.Float, nullable=True)  # Area in square meters
    height = db.Column(db.Float, default=5.0)  # Building height in meters, default to 5m
    levels = db.Column(db.Integer, nullable=True)  # Number of floor levels
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_geojson(self):
        """Convert to GeoJSON feature."""
        properties = self.properties or {}
        properties.update({
            'source': self.source,
            'id': self.source_id or str(self.id),
            'area': self.area,
            'height': self.height,
            'levels': self.levels
        })
        
        # Remove None values
        properties = {k: v for k, v in properties.items() if v is not None}
        
        return {
            'type': 'Feature',
            'geometry': self.geometry,
            'properties': properties
        }
    
    @classmethod
    def from_geojson(cls, feature, source):
        """Create a BuildingFootprint from a GeoJSON feature."""
        if not feature or not isinstance(feature, dict):
            return None
            
        geometry = feature.get('geometry')
        properties = feature.get('properties', {})
        source_id = properties.get('id', None)
        
        if source_id is None and 'osm_id' in properties:
            source_id = f"{source}_{properties['osm_id']}"
        elif source_id is None:
            source_id = f"{source}_{hash(json.dumps(geometry))}"
        
        # Extract height information if available
        height = 5.0  # Default height in meters
        levels = None
        
        # Check if height info is available in properties
        if 'height' in properties:
            try:
                height = float(properties['height'])
            except (ValueError, TypeError):
                pass
                
        elif 'building:height' in properties:
            try:
                height_str = properties['building:height']
                # Remove units if present (e.g., "10m" -> "10")
                height_str = height_str.lower().replace('m', '').strip()
                height = float(height_str)
            except (ValueError, TypeError, AttributeError):
                pass
        
        # Extract levels information
        if 'building:levels' in properties:
            try:
                levels = int(properties['building:levels'])
                # If we have levels but no height, estimate height (3m per level)
                if height == 5.0 and levels:
                    height = levels * 3.0
            except (ValueError, TypeError):
                pass
        
        # Create new BuildingFootprint
        return cls(
            source=source,
            source_id=source_id,
            geometry=geometry,
            properties={k: v for k, v in properties.items() if k not in ['id', 'source']},
            area=0.0,  # Would need to calculate area
            height=height,
            levels=levels
        )

class BoundingBox(db.Model):
    """Model to store bounding box data for API requests."""
    
    __tablename__ = 'bounding_boxes'
    
    id = db.Column(db.Integer, primary_key=True)
    north = db.Column(db.Float, nullable=False)
    south = db.Column(db.Float, nullable=False)
    east = db.Column(db.Float, nullable=False)
    west = db.Column(db.Float, nullable=False)
    area = db.Column(db.Float, nullable=False)  # Area in square degrees
    osm_count = db.Column(db.Integer, default=0)
    microsoft_count = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        """Convert to dictionary."""
        return {
            'id': self.id,
            'bounds': {
                'north': self.north,
                'south': self.south,
                'east': self.east,
                'west': self.west
            },
            'area': self.area,
            'osm_count': self.osm_count,
            'microsoft_count': self.microsoft_count,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    @classmethod
    def from_dict(cls, bounds_dict):
        """Create a BoundingBox from a dictionary."""
        if not bounds_dict:
            return None
            
        area = (bounds_dict['north'] - bounds_dict['south']) * (bounds_dict['east'] - bounds_dict['west'])
        
        return cls(
            north=bounds_dict['north'],
            south=bounds_dict['south'],
            east=bounds_dict['east'],
            west=bounds_dict['west'],
            area=area
        )