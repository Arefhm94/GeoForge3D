// Initialize the map
const map = L.map('map').setView([40.7128, -74.0060], 13);

// Add the base tile layer (dark theme)
L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
    subdomains: 'abcd',
    maxZoom: 20
}).addTo(map);

// Initialize variables to store state
let drawnRectangle = null;
let buildingLayers = L.layerGroup().addTo(map);
let buildingsData = null;

// Initialize the Leaflet Draw control
const drawControl = new L.Control.Draw({
    draw: {
        // Only allow rectangle drawing
        polyline: false,
        polygon: false,
        circle: false,
        circlemarker: false,
        marker: false,
        rectangle: {
            shapeOptions: {
                color: '#ffffff',
                weight: 2,
                fillOpacity: 0.2
            }
        }
    },
    edit: {
        featureGroup: new L.FeatureGroup(),
        edit: false
    }
});
map.addControl(drawControl);

// Reference UI elements
const fetchBuildingsBtn = document.getElementById('fetch-buildings-btn');
const clearBtn = document.getElementById('clear-btn');
const loadingIndicator = document.getElementById('loading');
const buildingInfo = document.getElementById('building-info');
const osmCount = document.getElementById('osm-count');
const msCount = document.getElementById('ms-count');
const totalCount = document.getElementById('total-count');

// Handle drawing complete event
map.on('draw:created', function(e) {
    // Remove any existing rectangle
    if (drawnRectangle) {
        map.removeLayer(drawnRectangle);
    }
    
    // Store the new rectangle
    drawnRectangle = e.layer;
    map.addLayer(drawnRectangle);
    
    // Enable the fetch buildings button
    fetchBuildingsBtn.disabled = false;
    
    // If there are buildings on the map, enable the clear button
    if (buildingLayers.getLayers().length > 0) {
        clearBtn.disabled = false;
    }
});

// Handle fetch buildings button click
fetchBuildingsBtn.addEventListener('click', async function() {
    if (!drawnRectangle) {
        showAlert('Please draw a rectangle on the map first.');
        return;
    }
    
    try {
        // Show loading indicator
        loadingIndicator.style.display = 'block';
        
        // Get the bounds of the drawn rectangle
        const bounds = drawnRectangle.getBounds();
        const boundsObj = {
            north: bounds.getNorth(),
            south: bounds.getSouth(),
            east: bounds.getEast(),
            west: bounds.getWest()
        };
        
        // Clear existing buildings
        buildingLayers.clearLayers();
        buildingInfo.innerHTML = '<p>Fetching building data...</p>';
        
        // Fetch buildings from API
        console.log('Fetching with bounds:', boundsObj);
        const response = await fetch('/api/buildings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ bounds: boundsObj })
        });
        
        if (!response.ok) {
            throw new Error(`API error: ${response.status}`);
        }
        
        // Parse response
        buildingsData = await response.json();
        
        // Display buildings on the map
        displayBuildings(buildingsData);
        
        // Update stats
        updateStats(buildingsData);
        
        // Enable clear button
        clearBtn.disabled = false;
        
    } catch (error) {
        console.error('Error fetching buildings:', error);
        buildingInfo.innerHTML = `<div class="alert alert-danger">Error: ${error.message}</div>`;
    } finally {
        // Hide loading indicator
        loadingIndicator.style.display = 'none';
    }
});

// Handle clear button click
clearBtn.addEventListener('click', function() {
    // Clear buildings layer
    buildingLayers.clearLayers();
    
    // Reset building info
    buildingInfo.innerHTML = '<p class="text-muted">Draw a rectangle and fetch buildings to see information.</p>';
    
    // Reset stats
    osmCount.textContent = '0';
    msCount.textContent = '0';
    totalCount.textContent = '0';
    
    // Disable buttons
    clearBtn.disabled = true;
    
    // If there's no rectangle drawn, disable fetch button too
    if (!drawnRectangle) {
        fetchBuildingsBtn.disabled = true;
    }
    
    // Reset buildings data
    buildingsData = null;
});

// Function to display buildings on the map
function displayBuildings(data) {
    if (!data || !data.features || data.features.length === 0) {
        buildingInfo.innerHTML = '<div class="alert alert-warning">No buildings found in the selected area.</div>';
        return;
    }
    
    // Clear existing layers
    buildingLayers.clearLayers();
    
    // Add each building to the map
    data.features.forEach(feature => {
        try {
            const source = feature.properties.source || 'unknown';
            const style = {
                weight: 1,
                opacity: 0.8,
                fillOpacity: 0.5,
                className: `${source}-building`
            };
            
            // Create GeoJSON layer
            const layer = L.geoJSON(feature, {
                style: style,
                onEachFeature: (feature, layer) => {
                    // Bind a popup with basic information
                    const sourceText = feature.properties.source === 'osm' ? 'OpenStreetMap' : 'Microsoft';
                    let popupContent = `<strong>Source:</strong> ${sourceText}<br>`;
                    
                    // Add additional properties if available
                    if (feature.properties.name) {
                        popupContent += `<strong>Name:</strong> ${feature.properties.name}<br>`;
                    }
                    if (feature.properties.building) {
                        popupContent += `<strong>Type:</strong> ${feature.properties.building}<br>`;
                    }
                    
                    layer.bindPopup(popupContent);
                    
                    // Add click handler to display building info
                    layer.on('click', () => {
                        displayBuildingInfo(feature);
                    });
                }
            });
            
            // Add to the layer group
            buildingLayers.addLayer(layer);
            
        } catch (error) {
            console.error('Error displaying building:', error);
        }
    });
    
    // Update the info panel
    buildingInfo.innerHTML = '<p>Click on a building to see details.</p>';
}

// Function to display building information in the info panel
function displayBuildingInfo(feature) {
    // Reset all styles
    buildingLayers.eachLayer(layer => {
        layer.setStyle({
            weight: 1,
            opacity: 0.8,
            fillOpacity: 0.5
        });
    });
    
    // Create HTML for the building info
    let html = '<div class="building-details">';
    
    // Add source information
    const sourceText = feature.properties.source === 'osm' ? 'OpenStreetMap' : 'Microsoft';
    html += `<div class="mb-2"><strong>Source:</strong> ${sourceText}</div>`;
    
    // Add other properties
    const excludeProps = ['source', 'id'];
    const props = Object.entries(feature.properties)
        .filter(([key]) => !excludeProps.includes(key))
        .sort(([a], [b]) => a.localeCompare(b));
    
    if (props.length > 0) {
        props.forEach(([key, value]) => {
            html += `<div class="mb-2"><strong>${key}:</strong> ${value}</div>`;
        });
    } else {
        html += '<div class="text-muted">No additional properties available.</div>';
    }
    
    html += '</div>';
    
    // Update the info panel
    buildingInfo.innerHTML = html;
}

// Function to update stats
function updateStats(data) {
    if (!data || !data.features) {
        osmCount.textContent = '0';
        msCount.textContent = '0';
        totalCount.textContent = '0';
        return;
    }
    
    // Count buildings by source
    const osm = data.features.filter(f => f.properties.source === 'osm').length;
    const ms = data.features.filter(f => f.properties.source === 'microsoft').length;
    const total = data.features.length;
    
    // Update UI
    osmCount.textContent = osm.toString();
    msCount.textContent = ms.toString();
    totalCount.textContent = total.toString();
}

// Utility function to show an alert
function showAlert(message, type = 'warning') {
    // Create alert element
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.setAttribute('role', 'alert');
    
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    // Add to the top of the page
    document.querySelector('.container-fluid').prepend(alert);
    
    // Remove after 5 seconds
    setTimeout(() => {
        alert.remove();
    }, 5000);
}